﻿# Real-State-Management system
This project represents the user interface for the property agent and supervisor of agent.
